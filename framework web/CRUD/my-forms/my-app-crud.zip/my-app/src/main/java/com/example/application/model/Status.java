package com.example.application.model;

public enum Status {
    Prospecao, Ativo, Inativo, Descartado
}
