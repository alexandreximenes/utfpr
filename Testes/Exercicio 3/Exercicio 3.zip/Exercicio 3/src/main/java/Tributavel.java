public interface Tributavel {

    Double calcula(Double salario);
}
