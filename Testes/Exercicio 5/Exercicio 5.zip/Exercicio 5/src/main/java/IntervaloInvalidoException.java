public class IntervaloInvalidoException extends Exception{

    public IntervaloInvalidoException(String message) {
        super(message);
    }
}
